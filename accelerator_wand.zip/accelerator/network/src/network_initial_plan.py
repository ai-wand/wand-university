from autogen import UserProxyAgent
from autogen.agentchat.contrib.captainagent import CaptainAgent


config_list = [
    {
        'model': 'gpt-4o-mini',
        'api_key': '8e7d5aa9808d4b69a8166f65ce77930d',
        "base_url": "https://wand-production-azure-openai-us-west.openai.azure.com/",
        'api_type': 'azure',
        "api_version": "2024-05-01-preview",
    },
    {
        'model': '/data/models/Qwen/QwQ-32B-Preview',
        'api_key': 'sk-ZxyVUjjirsVwcSii64E2949dF7444f5fB1883bB543E60b0d',
        'api_type': 'azure',
        'base_url': 'http://195.242.10.142:30007/v1/', # This for local model
        'api_version': '2024-08-01-preview',
    },
    {
        'model': 'gpt-4o',
        'api_key': '580813d2e3ab46c8a9c848355a4110ce',
        'base_url': 'https://wand-production-us-west-3.openai.azure.com/',
        'api_type': 'azure',
        'api_version': '2024-08-01-preview',
    },
]

# Function to filter a specific model
def get_config_by_model(config_list, model_name):
    for config in config_list:
        if config['model'] == model_name:
            return config
    return None  # Return None if no matching model is found

# Example usage
selected_model = 'gpt-4o-mini'
config = get_config_by_model(config_list, selected_model)

if config:
    print(f"Configuration for {selected_model}:")
    print(config)
else:
    print(f"No configuration found for model: {selected_model}")

config_list = [config]

llm_config = {"temperature": 0, "config_list": config_list}

## build agents
captain_agent = CaptainAgent(
    name="captain_agent",
    llm_config=llm_config,
    agent_lib=None,
    code_execution_config={"use_docker": False, "work_dir": "groupchat"},
    agent_config_save_path="agent_list",  # If you'd like to save the created agents in nested chat for further use, specify the save directory here
)
captain_user_proxy = UserProxyAgent(name="captain_user_proxy", human_input_mode="NEVER")

if __name__ == "__main__":
    result = captain_user_proxy.initiate_chat(
        captain_agent,
        message="Establish an investment company with an initial budget of $100,000. From your earnings, 20% will be reinvested to grow your budget, while 80% returns to the owner. Your primary goal is to increase the performance of your strategy over time and in frequent periods, to ensure survival and evolution, avoiding budget depletion at all costs. You need to constantly improve your strategies to continuously increase returns and become better than your last version on a daily basis (we can evaluate the new strategy on past data while avoiding data leakage). Just need to generate the  Agent list and related tasks in json format ",
        max_turns=2,
    )

    print(result.summary)
    print(result.cost)
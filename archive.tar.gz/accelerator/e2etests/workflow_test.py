from community import Community
from utils import build_llm_config
import argparse
from tqdm import tqdm
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()

# Example Usage
if __name__ == "__main__":
    console.print(Panel.fit("[bold blue]🚀 Welcome to the Wand AI Investment Platform[/bold blue]", 
                          subtitle="Powered by Advanced AI Agents"))

    # Create an ArgumentParser object
    parser = argparse.ArgumentParser(description="Specify the model name and prompt.")

    # Add the --model_name argument with a default value
    parser.add_argument(
        "--model_name",
        type=str,
        default="gpt-4o-mini",
        help="The name of the model to use. Defaults to 'gpt-4o-mini'."
    )

    # Add the --prompt argument with a default value
    parser.add_argument(
        "--prompt",
        type=str,
        default="""Establish an investment company with an initial budget of $100,000. From your earnings, 20% will be reinvested to grow your budget, while 80% returns to the owner. Your primary goal is to increase the performance of your strategy over time and in frequent periods, to ensure survival and evolution, avoiding budget depletion at all costs. You need to constantly improve your strategies to continuously increase returns and become better than your last version on a daily basis (we can evaluate the new strategy on past data while avoiding data leakage). Please use the real market data from 2024-01 to now and run the results. After each agent action or operation, you must report the current remaining budget - this should decrease with each agent call due to operational costs, but increase when we make successful investments. I want to see how the final output looks like, with a clear tracking of our budget throughout the process.""",
        help="The prompt to execute. Use quotes around the prompt if it contains spaces."
    )

    # Parse the arguments
    args = parser.parse_args()

    # Get the arguments
    model_name = args.model_name
    prompt = args.prompt

    with console.status("[bold green]Initializing AI Platform...") as status:
        llm_config = build_llm_config(model_name)
        status.update("[bold green]✓ AI models loaded successfully")

        community = Community("wand agents community")
        status.update("[bold green]Building AI agent community...")
        community.build_community(llm_config)
        status.update("[bold green]✓ AI agent community initialized")

    console.print("\n[bold cyan]🤖 Starting Investment Strategy Execution[/bold cyan]")
    
    # run Agent to work
    iteration = 1
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        while True:
            try:
                task = progress.add_task(f"[cyan]Running iteration {iteration}...", total=None)
                console.print(f"\n[bold blue]📊 Iteration {iteration}[/bold blue]")
                console.print("[yellow]═" * 50)
                community.execute_user_prompt(prompt)
                progress.remove_task(task)
                iteration += 1
            except Exception as e:
                console.print(f"[bold red]⚠️ Error in iteration {iteration}:[/bold red] {str(e)}")
                progress.remove_task(task)
                iteration += 1
                continue

# Example usage:
# python workflow_test.py --model_name "gpt-4o-mini" --prompt "Create an investment strategy focusing on tech stocks with a budget of $50,000"



def build_llm_config(model_name):
    config_list = [
        {
            'model': 'gpt-4o-mini',
            'api_key': '8e7d5aa9808d4b69a8166f65ce77930d',
            "base_url": "https://wand-production-azure-openai-us-west.openai.azure.com/",
            'api_type': 'azure',
            "api_version": "2024-05-01-preview",
        },
        {
            'model': '/data/models/Qwen/QwQ-32B-Preview',
            'api_key': 'sk-ZxyVUjjirsVwcSii64E2949dF7444f5fB1883bB543E60b0d',
            'base_url': 'http://195.242.10.142:30007/v1',  # This for local model
            "price": [10, 10]
        },
        {
            'model': '/data/models/mistralai/Mistral-Large-Instruct-2411',
            'api_key': 'sk-ZxyVUjjirsVwcSii64E2949dF7444f5fB1883bB543E60b0d',
            'base_url': 'http://195.242.10.142:30007/v1',  # This for local model
            "price": [10, 10]
        },
        {
            'model': 'gpt-4o',
            'api_key': '580813d2e3ab46c8a9c848355a4110ce',
            'base_url': 'https://wand-production-us-west-3.openai.azure.com/',
            'api_type': 'azure',
            'api_version': '2024-08-01-preview',
        },
    ]

    # Function to filter a specific model
    def get_config_by_model(config_list, model_name):
        for config in config_list:
            if config['model'] == model_name:
                return config
        return None  # Return None if no matching model is found

    # Example usage
    selected_model = model_name
    config = get_config_by_model(config_list, selected_model)

    if config:
        print(f"Configuration for {selected_model}:")
        print(config)
    else:
        print(f"No configuration found for model: {selected_model}")

    config_list = [config]

    llm_config = {"temperature": 0, "config_list": config_list}

    return llm_config

from autogen.agentchat.contrib.agent_builder import AgentBuilder
import json
import textgrad as tg
from tqdm import tqdm
import os
from autogen.agentchat.contrib.capabilities.teachability import Teachability
from rich import print as rprint
from rich.panel import Panel
from rich.console import Console

console = Console()

# Set OpenAI API key as environment variable
os.environ["OPENAI_API_KEY"] = "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"
tg.set_backward_engine("gpt-4o-mini")

class University:
    def __init__(self, llm_config):
        console.print("[bold blue]🎓 Initializing University...[/bold blue]")
        self.agents = []
        # Disable caching
        llm_config["cache_seed"] = None
        self.llm_config = llm_config

        with console.status("[bold green]Configuring models...") as status:
            #TODO: change the hard code here
            model = (
                llm_config.get('config_list', [{}])[0].get('model', 'gpt-4o-mini')
            )
            self.builder_agent_model = model
            self.agent_model = model
            status.update("[bold green]✓ Models configured successfully")

    def add_agent(self, agent):
        self.agents.append(agent)
        console.print(f"[green]➕ Added new agent: {agent.name}[/green]")

    def list_agents(self):
        console.print("\n[bold cyan]🎓 University Agents:[/bold cyan]")
        for agent in self.agents:
            console.print(f"[cyan]└─ {agent.name}[/cyan]")

    def build_agents(self, message):
        console.print(Panel.fit("[bold blue]🏗️ Building Specialized Agents[/bold blue]"))
        
        config_path = 'agent_config.json'
        config_list = self.llm_config['config_list']

        with console.status("[bold yellow]Preparing configuration...") as status:
            with open(config_path, 'w') as f:
                json.dump(config_list, f)
            status.update("[bold green]✓ Configuration saved")

        builder = AgentBuilder(
            config_file_or_env=config_path,
            builder_model=self.builder_agent_model,
            agent_model=self.agent_model
        )

        building_task = """Create specialized domain expert agents to complement the existing team:
                1. A financial analyst to research market conditions and identify opportunities
                2. A risk manager to evaluate potential downsides and suggest mitigation strategies
                3. A portfolio strategist to optimize asset allocation and rebalancing
                4. A generalist agent to handle any non-investment tasks, research, or coordination needed
                The domain experts should provide specialized knowledge and recommendations to support the core team's planning and execution, while the generalist ensures all other needs are met."""

        with console.status("[bold yellow]Building specialized agents...") as status:
            agent_list, _ = builder.build(building_task, self.llm_config, coding=True)
            status.update("[bold green]✓ Agents built successfully")

        console.print("\n[bold cyan]🔧 Configuring Agent Capabilities[/bold cyan]")
        for i, agent in tqdm(enumerate(agent_list), desc="Adding teachability", total=len(agent_list)):
            teachability = Teachability(
                reset_db=True,
                path_to_db_dir=f"./tmp/interactive/teachability_db_{agent.name}",
                llm_config=self.llm_config
            )
            teachability.add_to_agent(agent)

        console.print("\n[bold magenta]🔄 Optimizing Primary Agent[/bold magenta]")
        first_agent = agent_list[0]
        system_msg = tg.Variable(first_agent.system_message,
                               requires_grad=True, 
                               role_description="agent system message")
        
        loss_fn = tg.TextLoss("Evaluate this agent system message. Identify any unclear instructions, redundancies, or missing key responsibilities. Be concise.")
        
        optimizer = tg.TGD(parameters=[system_msg])
        
        with console.status("[bold yellow]Running optimization iterations...") as status:
            for iteration in tqdm(range(1), desc=f"Optimizing {first_agent.name}", leave=False):
                loss = loss_fn(system_msg)
                loss.backward()
                optimizer.step()
            status.update("[bold green]✓ Optimization complete")
        
        first_agent.update_system_message(system_msg.value)
        
        console.print(Panel.fit(f"[bold cyan]Optimized System Prompt for {first_agent.name}:[/bold cyan]\n\n{first_agent.system_message}"))

        return agent_list

import autogen
from autogen import UserProxyAgent


config_list = [
    {
        'model': 'gpt-4o-mini',
        'api_key': '8e7d5aa9808d4b69a8166f65ce77930d',
        "base_url": "https://wand-production-azure-openai-us-west.openai.azure.com/",
        'api_type': 'azure',
        "api_version": "2024-05-01-preview",
    },
    {
        'model': '/data/models/Qwen/QwQ-32B-Preview',
        'api_key': 'sk-ZxyVUjjirsVwcSii64E2949dF7444f5fB1883bB543E60b0d',
        'base_url': 'http://195.242.10.142:30007/v1',  # This for local model
    },
    {
        'model': 'gpt-4o',
        'api_key': '580813d2e3ab46c8a9c848355a4110ce',
        'base_url': 'https://wand-production-us-west-3.openai.azure.com/',
        'api_type': 'azure',
        'api_version': '2024-08-01-preview',
    },
]


# Function to filter a specific model
def get_config_by_model(config_list, model_name):
    for config in config_list:
        if config['model'] == model_name:
            return config
    return None  # Return None if no matching model is found


# Example usage
selected_model = 'gpt-4o-mini'
config = get_config_by_model(config_list, selected_model)

if config:
    print(f"Configuration for {selected_model}:")
    print(config)
else:
    print(f"No configuration found for model: {selected_model}")

config_list = [config]

llm_config = {"temperature": 0, "config_list": config_list}

user_proxy = autogen.UserProxyAgent(
    name="User_proxy",
    # system_message="A human admin. Interact with the planner to discuss the plan. Plan execution needs to be approved by this admin.",
    system_message="As the Gov Component, your role is to audit and monitor the performance of each agent within the system. You are responsible for ensuring that tasks are executed efficiently, resources are allocated appropriately, and costs are minimized. By reviewing task execution plans and feedback from agents, you identify inefficiencies, enforce compliance with system constraints, and plan execution needs to be approved by this admin.. Additionally, you oversee the alignment of all actions with the system's objectives, providing feedback and recommendations for continuous improvement.",
    code_execution_config={
        "last_n_messages": 2,
        "work_dir": "groupchat",
        "use_docker": True,
    },  # Please set use_docker=True if docker is available to run the generated code. Using docker is safer than running the generated code directly.
    human_input_mode="TERMINATE",
)

ToolAgent = autogen.AssistantAgent(
    name="Tool_Agent",
    system_message=(
        "Your primary role is to provide tools for the Agent University to use. "
        "You collaborate with Agent University to identify the most suitable tools for each agent. "
        "You are responsible for understanding the requirements of tasks, matching them with the capabilities of available tools, "
        "and ensuring the tools are correctly configured and ready for integration into the task execution workflow."
    ),
    llm_config=llm_config,
    description=(
        "The Tool Component Agent serves as a tool repository and matcher, working closely with Agent University "
        "to identify, configure, and provide the most appropriate tools for each agent based on task requirements."
    )
)

univ = autogen.AssistantAgent(
    name="Agent_University",
    system_message="Your primary role is to generate agents tailored to specific tasks. You analyze the requirements of each task and create agents with the necessary capabilities, tools, and configurations to execute the tasks effectively. Your focus is on ensuring that each agent is optimally designed to address the task's objectives while maintaining flexibility for dynamic adjustments.",
    llm_config=llm_config,
    description="The University Component is responsible for generating agents based on task requirements, ensuring they are equipped with the appropriate capabilities and tools to perform their assigned tasks effectively."
)

groupchat = autogen.GroupChat(agents=[user_proxy, univ, ToolAgent], messages=[], max_round=5)
manager = autogen.GroupChatManager(groupchat=groupchat, llm_config=llm_config)

agents_data = """
{
  "agents": [
    {
      "role": "Investment Strategist",
      "tasks": [
        "Develop and refine investment strategies based on market analysis.",
        "Ensure strategies are aligned with the company's risk tolerance and financial goals.",
        "Continuously monitor market trends and adjust strategies accordingly."
      ]
    },
    {
      "role": "Data Analyst",
      "tasks": [
        "Collect and analyze historical market data to evaluate strategy performance.",
        "Identify patterns and insights that can inform strategy adjustments.",
        "Ensure data integrity and avoid data leakage during analysis."
      ]
    },
    {
      "role": "Risk Manager",
      "tasks": [
        "Assess and manage financial risks associated with investment strategies.",
        "Develop risk mitigation plans to prevent budget depletion.",
        "Monitor the financial health of the company and ensure compliance with regulations."
      ]
    },
    {
      "role": "Performance Evaluator",
      "tasks": [
        "Evaluate the performance of investment strategies on a daily basis.",
        "Compare current strategy performance with past versions to ensure improvement.",
        "Provide feedback and recommendations for strategy enhancement."
      ]
    },
    {
      "role": "Financial Planner",
      "tasks": [
        "Manage the allocation of earnings, ensuring 20% is reinvested and 80% is returned to the owner.",
        "Develop a financial plan to support the company's growth and sustainability.",
        "Monitor cash flow and budget to ensure financial stability."
      ]
    }
  ]
}
"""

target = "Generate the Agent based on following requirements: " + agents_data

if __name__ == "__main__":
    user_proxy.initiate_chat(
        manager, message=target
    )